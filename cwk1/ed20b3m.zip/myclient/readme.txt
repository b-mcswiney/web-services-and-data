##### How to use system
To run: python3 client.py

COMMANDS:
help - Display this help message
  login <url> - Log in to the system
  logout - Log out of the system
  post - Post a new story
  list - List all news sites
  news - Get the lastest news
     [Options]
       [-id=] - id of the news service
       [-cat=] - category of news
       [-reg=] - region of news
       [-date=] - date of news
  exit - Exit the program

Python anywhere domain: http://ed20b3m.pythonanywhere.com
username: ammar
password: password1234

note: login function in client requires the "http://" prefix


